from distutils.core import setup

setup(
    name='generator',
    version='0.0.1',
    packages=[''],
    url='https://github.com/alexiasa/balanced-password/',
    license='',
    author='tapes',
    author_email='alexiasa@users.noreply.github.com',
    description='A Python program to generate balanced diceware passwords',
    install_requires=['diceware'],
)
