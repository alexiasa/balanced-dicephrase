from distutils.core import setup

setup(
    name='balanced-pw',
    version='0.0.1',
    packages=[''],
    url='https://github.com/alexiasa/balanced-password/',
    license='',
    author='alexiasa',
    author_email='alexiasa@users.noreply.github.com',
    description='A Python program to generate balanced diceware passwords',
    install_requires=['diceware'],
)
